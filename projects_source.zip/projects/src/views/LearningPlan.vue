<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Header -->
    <div class="flex items-center justify-between mb-8">
      <div>
        <h1 class="text-2xl font-bold text-slate-800">{{ t('plan.title') }}</h1>
        <p class="text-slate-500 mt-1">{{ t('plan.subtitle') }}</p>
      </div>
      <div class="flex gap-2">
        <button class="px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 rounded-lg">{{ t('plan.week') }}</button>
        <button class="px-4 py-2 text-sm font-medium text-slate-500 hover:bg-slate-100 rounded-lg transition-colors">{{ t('plan.month') }}</button>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Left: Ability Curve + Radar -->
      <div class="space-y-6">
        <!-- Ability Improvement Curve -->
        <div class="card p-6">
          <h3 class="text-base font-semibold text-slate-800 mb-4">{{ t('plan.abilityCurve') }}</h3>
          <div ref="abilityChartRef" class="w-full h-56"></div>
        </div>

        <!-- Radar Analysis -->
        <div class="card p-6">
          <h3 class="text-base font-semibold text-slate-800 mb-4">{{ t('plan.radarAnalysis') }}</h3>
          <div ref="radarChartRef" class="w-full h-64"></div>
          <p class="text-sm text-slate-500 mt-3 text-center">{{ t('plan.radarTip') }}</p>
        </div>
      </div>

      <!-- Right: Progress Charts -->
      <div class="lg:col-span-2 space-y-6">
        <h3 class="text-base font-semibold text-slate-800">{{ t('plan.progressCurves') }}</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div v-for="metric in metrics" :key="metric.key" class="card p-5">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <span class="text-lg">{{ metric.icon }}</span>
                <span class="text-sm font-medium text-slate-700">{{ metric.label }}</span>
              </div>
              <span class="text-lg font-bold" :style="{ color: metric.color }">{{ metric.value }}%</span>
            </div>
            <div :ref="el => { if (el) metricRefs[metric.key] = el as HTMLElement }" class="w-full h-28"></div>
            <div class="text-xs text-emerald-600 mt-1">+ {{ metric.improvement }}% {{ t('plan.thisWeek') }}</div>
          </div>
        </div>

        <!-- Weekly Plan -->
        <div class="card p-6">
          <h3 class="text-base font-semibold text-slate-800 mb-4">{{ t('plan.weeklyPlan') }}</h3>
          <div class="space-y-3">
            <div v-for="(day, idx) in weekPlan" :key="idx" class="flex items-center gap-4 p-3 rounded-xl bg-slate-50 hover:bg-indigo-50/50 transition-colors">
              <div class="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600 font-semibold text-sm">{{ day.day }}</div>
              <div class="flex-1">
                <div class="text-sm font-medium text-slate-800">{{ day.task }}</div>
                <div class="text-xs text-slate-500">{{ day.duration }}</div>
              </div>
              <div class="w-20 h-2 bg-slate-200 rounded-full overflow-hidden">
                <div class="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full" :style="{ width: day.progress + '%' }"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Recommended Scenes -->
        <div class="card p-6">
          <h3 class="text-base font-semibold text-slate-800 mb-4">{{ t('plan.recommended') }}</h3>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div v-for="scene in recommendedScenes" :key="scene.id" class="p-4 rounded-xl border border-slate-200 hover:border-indigo-300 hover:shadow-sm transition-all cursor-pointer" @click="goToScene(scene.id)">
              <div class="text-2xl mb-2">{{ scene.icon }}</div>
              <div class="text-sm font-medium text-slate-800">{{ scene.name }}</div>
              <div class="text-xs text-slate-500 mt-1">{{ scene.desc }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import * as echarts from 'echarts'
import { useChatStore } from '../stores/chat'
import { useI18n } from '../i18n'

const router = useRouter()
const chatStore = useChatStore()
const { t } = useI18n()

const abilityChartRef = ref<HTMLElement>()
const radarChartRef = ref<HTMLElement>()
const metricRefs = ref<Record<string, HTMLElement>>({})

const metrics = [
  { key: 'accuracy', label: 'plan.accuracy', icon: '🎯', value: 86, color: '#6366f1', improvement: 4, data: [80, 82, 83, 84, 86, 85, 86] },
  { key: 'fluency', label: 'plan.fluency', icon: '🗣️', value: 78, color: '#10b981', improvement: 4, data: [70, 72, 74, 75, 76, 77, 78] },
  { key: 'completeness', label: 'plan.completeness', icon: '📝', value: 72, color: '#f59e0b', improvement: 6, data: [65, 66, 68, 70, 71, 70, 72] },
  { key: 'standard', label: 'plan.standard', icon: '🎙️', value: 80, color: '#ec4899', improvement: 7, data: [75, 76, 77, 78, 77, 79, 80] },
  { key: 'vocabulary', label: 'plan.vocabulary', icon: '📚', value: 83, color: '#06b6d4', improvement: 6, data: [78, 79, 80, 81, 82, 82, 83] },
]

const weekPlan = [
  { day: 'Mon', task: 'Restaurant ordering practice', duration: '15 min', progress: 100 },
  { day: 'Tue', task: 'Airport check-in dialogue', duration: '20 min', progress: 80 },
  { day: 'Wed', task: 'Vocabulary building - Travel', duration: '10 min', progress: 60 },
  { day: 'Thu', task: 'Pronunciation training', duration: '15 min', progress: 40 },
  { day: 'Fri', task: 'Free conversation practice', duration: '25 min', progress: 20 },
]

const recommendedScenes = [
  { id: 'restaurant', icon: '️', name: 'Restaurant', desc: 'Ordering & dining' },
  { id: 'airport', icon: '✈️', name: 'Airport', desc: 'Check-in & boarding' },
  { id: 'interview', icon: '', name: 'Interview', desc: 'Job interview skills' },
]

const dates = ['3/12', '3/13', '3/14', '3/15', '3/16', '3/17', '3/18']

const initAbilityChart = () => {
  if (!abilityChartRef.value) return
  const chart = echarts.init(abilityChartRef.value)
  chart.setOption({
    grid: { top: 10, right: 10, bottom: 20, left: 35 },
    xAxis: { type: 'category', data: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'], axisLine: { lineStyle: { color: '#e2e8f0' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
    yAxis: { type: 'value', min: 60, max: 100, axisLine: { show: false }, splitLine: { lineStyle: { color: '#f1f5f9' } }, axisLabel: { color: '#94a3b8', fontSize: 11, formatter: '{value}%' } },
    series: [{
      type: 'line',
      data: [65, 68, 72, 75, 78, 82],
      smooth: true,
      symbol: 'circle',
      symbolSize: 6,
      lineStyle: { color: '#6366f1', width: 2.5 },
      itemStyle: { color: '#6366f1' },
      areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(99,102,241,0.2)' }, { offset: 1, color: 'rgba(99,102,241,0.02)' }]) },
    }],
    tooltip: { trigger: 'axis', formatter: '{b}: {c}%' },
  })
  window.addEventListener('resize', () => chart.resize())
}

const initRadarChart = () => {
  if (!radarChartRef.value) return
  const chart = echarts.init(radarChartRef.value)
  chart.setOption({
    radar: {
      indicator: [
        { name: 'Pronunciation', max: 100 },
        { name: 'Vocabulary', max: 100 },
        { name: 'Grammar', max: 100 },
        { name: 'Fluency', max: 100 },
        { name: 'Comprehension', max: 100 },
      ],
      shape: 'polygon',
      splitNumber: 4,
      axisName: { color: '#64748b', fontSize: 11 },
      splitLine: { lineStyle: { color: '#e2e8f0' } },
      splitArea: { areaStyle: { color: ['rgba(99,102,241,0.02)', 'rgba(99,102,241,0.05)'] } },
      axisLine: { lineStyle: { color: '#e2e8f0' } },
    },
    series: [{
      type: 'radar',
      data: [{
        value: [85, 83, 78, 78, 80],
        name: 'Current',
        lineStyle: { color: '#6366f1', width: 2 },
        itemStyle: { color: '#6366f1' },
        areaStyle: { color: 'rgba(99,102,241,0.15)' },
      }],
    }],
  })
  window.addEventListener('resize', () => chart.resize())
}

const initMetricChart = (key: string, el: HTMLElement, data: number[], color: string) => {
  const chart = echarts.init(el)
  chart.setOption({
    grid: { top: 5, right: 5, bottom: 5, left: 5 },
    xAxis: { type: 'category', data: dates, show: false },
    yAxis: { type: 'value', show: false },
    series: [{
      type: 'line',
      data,
      smooth: true,
      symbol: 'circle',
      symbolSize: 4,
      lineStyle: { color, width: 2 },
      itemStyle: { color },
      areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: color + '30' }, { offset: 1, color: color + '05' }]) },
    }],
    tooltip: { trigger: 'axis', formatter: '{c}%' },
  })
  window.addEventListener('resize', () => chart.resize())
}

const goToScene = (id: string) => {
  chatStore.setScene(id as any)
  router.push('/chat')
}

onMounted(() => {
  nextTick(() => {
    initAbilityChart()
    initRadarChart()
    metrics.forEach(m => {
      const el = metricRefs.value[m.key]
      if (el) initMetricChart(m.key, el, m.data, m.color)
    })
  })
})
</script>
