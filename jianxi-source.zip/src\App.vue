<template>
  <div class="min-h-screen">
    <nav class="bg-white/80 backdrop-blur-md border-b border-indigo-100 sticky top-0 z-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
          <div class="flex items-center gap-2 cursor-pointer" @click="router.push('/')">
            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-sm">V</div>
            <span class="text-lg font-bold text-slate-800">VerbFlow</span>
          </div>

          <div class="hidden md:flex items-center gap-1">
            <router-link
              v-for="item in navItems"
              :key="item.path"
              :to="item.path"
              class="px-4 py-2 text-sm font-medium rounded-lg transition-colors"
              :class="isActive(item.path) ? 'text-indigo-600 bg-indigo-50' : 'text-slate-600 hover:text-indigo-600 hover:bg-indigo-50/50'"
            >
              {{ t(item.label) }}
            </router-link>
          </div>

          <div class="flex items-center gap-3">
            <button
              @click="toggleLocale"
              class="px-3 py-1.5 text-sm font-medium rounded-lg border border-indigo-200 text-indigo-600 hover:bg-indigo-50 transition-colors"
            >
              {{ locale === 'zh' ? 'EN' : '中文' }}
            </button>
            <button
              v-if="user.isLoggedIn"
              class="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-indigo-50 transition-colors"
              :title="user.authUser?.email || ''"
              @click="router.push('/auth')"
            >
              <span
                class="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-medium"
                :style="{ background: user.authUser?.avatarColor || '#818cf8' }"
              >
                {{ user.displayName.charAt(0).toUpperCase() }}
              </span>
            </button>
            <button
              v-else
              class="px-4 py-1.5 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
              @click="router.push('/auth')"
            >
              {{ t('auth.login') }}
            </button>
          </div>
        </div>
      </div>
    </nav>

    <!-- 预览模式提示条：未注册可预览全部功能，不可使用 -->
    <div v-if="!user.isLoggedIn && !user.authLoading" class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-1.5 flex items-center justify-center gap-2 text-xs sm:text-sm">
        <svg class="h-3.5 w-3.5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
          <circle cx="12" cy="12" r="3" />
        </svg>
        <span>{{ t('preview.banner') }}</span>
        <button
          @click="router.push({ path: '/auth', query: { mode: 'register' } })"
          class="font-semibold underline underline-offset-2 hover:text-indigo-200 transition-colors"
        >
          {{ t('preview.register') }}
        </button>
      </div>
    </div>

    <router-view v-slot="{ Component }">
      <transition name="page" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from './stores/user'
import { useI18n } from './i18n'
import { useLocaleStore } from './stores/locale'

const router = useRouter()
const route = useRoute()
const user = useUserStore()
const { t, locale } = useI18n()
const localeStore = useLocaleStore()

const navItems = [
  { path: '/', label: 'nav.home' },
  { path: '/scenes', label: 'nav.scenes' },
  { path: '/chat', label: 'nav.chat' },
  { path: '/community', label: 'nav.community' },
  { path: '/learning-plan', label: 'nav.learning' },
]

const isActive = (path: string) => {
  if (path === '/') return route.path === '/'
  return route.path.startsWith(path)
}

const toggleLocale = () => {
  localeStore.setLocale(locale.value === 'zh' ? 'en' : 'zh')
}
</script>

<style scoped>
.page-enter-active,
.page-leave-active {
  transition: all 0.3s ease;
}
.page-enter-from {
  opacity: 0;
  transform: translateY(12px);
}
.page-leave-to {
  opacity: 0;
  transform: translateY(-12px);
}
</style>
